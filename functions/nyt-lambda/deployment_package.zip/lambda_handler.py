import json
import requests

ERROR_RESPONSE = {
    "statusCode": 500,
    "body": "Failed to get latest from NYT"
}

ORACLE_URI = "https://www.nytimes.com/svc/crosswords/v2/oracle/daily.json"
DIMENSION = 15
SUNDAY_DIMENSION = 21

def read_json_file(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data

def send_api_request(endpoint):
    try:
        response = requests.get(endpoint)
        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            # Return the JSON response
            return response.json()
        else:
            print(f"Error: {response.status_code}")
            return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None


def handler(event, context):
    # 1. API CALL - use oracle to get latest puzzle
    oracle_response = send_api_request(ORACLE_URI)
    print(oracle_response)

    # 2. API CALL - get details of latest puzzle

    # response = read_json_file('example.json')
    # results = response.get("results")
    results = None


    if not results:
        return ERROR_RESPONSE
        
    print(results)

    # 3. convert puzzle data into dictionary
    # clue -> word

    puzzle_data = results[0].get("puzzle_data")
    if not puzzle_data:
        return ERROR_RESPONSE
    
    dotw = results[0].get("puzzle_meta").get("printeDotw")
    dimension = SUNDAY_DIMENSION if dotw == 7 else DIMENSION

    clues = puzzle_data.get("clues")
    print(f"clues: {clues}")
    answers = puzzle_data.get("answers")
    clue_list_order = puzzle_data.get("clueListOrder")

    if not clues or not answers or not clue_list_order:
        return []

    puzzle_clues = []

    for direction in clue_list_order:
        print(f"direction: {direction}")
        
        # step to parse the 1d representation of the board. 
        # increment by dimension each time if going down
        step = 1 if direction == "Across" else dimension

        # we only want the first char of "A" or "D" bc that's how it appears in the clue. so direction[0]
        for clue in clues.get(direction[0], []):
            print(f"clue: {clue}")
            clue_num = clue.get("clueNum")
            clue_value = clue.get("value")
            clue_start = clue.get("clueStart")
            clue_end = clue.get("clueEnd")

            if clue_num is not None and clue_value and clue_start is not None and clue_end is not None:
                word = ''.join(answers[clue_start:clue_end + 1:step])
                puzzle_clues.append((clue_value, word))


    return {
        'statusCode': 200,
        'body': puzzle_clues
    }